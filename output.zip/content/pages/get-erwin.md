---
title: Get Erwin
date: 2020-06-20
category:
img: 
summary: How to download the Erwin-SSG static site generator
slug: get-erwin
---

Get Erwin on github:
[Erwin SSG Github Page](https://github.com/der2b2/erwin)

See [installation instructions](/install) for more info.