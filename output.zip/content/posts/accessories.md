---
title: Accessories Generators
date: 2020-05-19
tags: Features
img: louis-reed-JeInkKlI2Po-unsplash.jpg
summary: Automatic creation of Sitemap, RSS Feed, Webmanifest, Social Cards.
slug: accessories
---

## Sitemap creation

Posts and Pages are included.

## RSS Feed Creation
Last 5 posts are included, usefull for blogs and news.

## Social Cards

Metadata for sharing on social platforms are included:
- Twitter card
- Facebook Card
- Google Metadata

## Webmanifest

There is no service worker because for all of my use cases the service worker is just annoying. 
But Erwin is generating a webmanifest with some metadata like color schemes and icons.