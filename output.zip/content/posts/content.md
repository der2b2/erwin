---
title: The Content
date: 2020-05-19
tags: Features
img: skye-studios-NDLLFxTELrU-unsplash.jpg
summary: We have Pages, Posts, Tags, Categories
slug: content
---

## Markdown
All content is written in markdown with additional metatags.

## Pages
Pages are for static or "classic" content. 

## Categories
You can sort pages by categories (every page can have zero or one category)

## Posts
Classic blog post, also useful for news on a corporate site

## Tags 
You can sort posts by tags (every post must have at least one or more tags, comma separated)