---
title: Impressum
date: 2020-06-15
category:
img: 
summary: Not quite french bread which has great taste and stays fresh for longer.
slug: impressum
---

Bastian Schröder

Buchenweg 12  
58540 Meinerzhagen  
Germany

Contact:  
b.schroeder@medienspot.de