---
title: Support
date: 2020-06-19
category:
img: chuttersnap-eH_ftJYhaTY-unsplash.jpg
summary: Not quite french bread which has great taste and stays fresh for longer.
slug: support
---

Bastian Schröder

Buchenweg 12  
58540 Meinerzhagen  
Germany

Contact:  
b.schroeder@medienspot.de